import { getModuleContent } from '@/lib/markdown';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import CompletionTerminal from './CompletionTerminal';
import Link from 'next/link';
import { Terminal } from 'lucide-react';

export default async function SubjectPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const content = getModuleContent(id);

  if (!content) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] text-red-500 font-mono p-8 flex flex-col items-center justify-center selection:bg-red-500 selection:text-black">
        <div className="border-4 border-red-500 p-8 max-w-2xl w-full">
          <h1 className="text-4xl md:text-6xl font-black uppercase tracking-tighter mb-4 animate-pulse">Fatal Error</h1>
          <p className="text-red-400 text-lg uppercase tracking-widest border-t-2 border-red-500 pt-4">Module [{id}] not localized in databank.</p>
          <Link href="/" className="mt-8 inline-block bg-red-500 text-black px-6 py-3 font-bold uppercase hover:bg-white hover:text-black transition-colors">Return to Root</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#E0E0E0] p-4 sm:p-8 font-sans selection:bg-[#00FF41] selection:text-black">
      <div className="max-w-4xl mx-auto mb-8 flex justify-between items-center">
        <Link href="/" className="text-[#888] font-mono text-xs hover:text-white uppercase flex items-center gap-2 transition-colors">
          <span className="text-[#00FF41]">&lt;</span> Return to Dashboard
        </Link>
      </div>

      <div className="max-w-4xl mx-auto border-2 border-[#1A1A1A] bg-[#111] shadow-[8px_8px_0px_0px_#00FF41]">
        <header className="border-b-2 border-[#1A1A1A] p-4 sm:p-6 bg-[#050505] flex justify-between items-center gap-4">
          <div className="font-mono text-xs text-[#00FF41] uppercase tracking-widest flex items-center gap-3">
            <Terminal size={18} /> Intra Viewer v2.06
          </div>
          <div className="font-mono text-[10px] text-[#666] uppercase bg-[#1A1A1A] px-3 py-1">Target: {id}.md</div>
        </header>
        
        <div className="p-4 sm:p-8 lg:p-12">
          <div className="prose prose-invert max-w-none 
            prose-headings:font-black prose-headings:text-white prose-headings:tracking-tighter prose-headings:uppercase
            prose-h1:text-4xl prose-h1:border-b-2 prose-h1:border-[#00FF41] prose-h1:pb-4 prose-h1:mb-12
            prose-h2:text-2xl prose-h2:text-[#E0E0E0] prose-h2:mt-12 prose-h2:mb-6
            prose-h3:text-xl prose-h3:text-[#00FF41] hover:prose-h3:bg-[#00FF41] hover:prose-h3:text-black transition-colors prose-h3:inline-block prose-h3:px-2 prose-h3:-ml-2 prose-h3:mt-8 prose-h3:mb-4
            prose-h4:text-lg prose-h4:text-white prose-h4:mt-8
            prose-p:text-gray-300 prose-p:leading-relaxed prose-p:font-sans
            prose-a:text-[#00FF41] prose-a:no-underline hover:prose-a:underline hover:prose-a:decoration-2
            prose-code:bg-[#050505] prose-code:text-[#00FF41] prose-code:font-mono prose-code:px-1.5 prose-code:py-0.5 prose-code:border prose-code:border-[#333] prose-code:rounded-none prose-code:before:content-none prose-code:after:content-none
            prose-pre:bg-[#050505] prose-pre:border-2 prose-pre:border-[#333] prose-pre:rounded-none prose-pre:p-4
            prose-hr:border-[#333] prose-hr:border-2 prose-hr:my-8
            prose-strong:text-white prose-strong:font-black
            prose-li:text-gray-300 prose-li:my-1
            prose-ul:list-square prose-ul:marker:text-[#00FF41]
          ">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {content}
            </ReactMarkdown>
          </div>
        </div>
      </div>
      
      <CompletionTerminal exerciseId={id} />
    </div>
  );
}
