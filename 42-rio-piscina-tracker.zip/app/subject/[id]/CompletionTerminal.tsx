"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Terminal } from 'lucide-react';

interface CompletionTerminalProps {
  exerciseId: string;
}

export default function CompletionTerminal({ exerciseId }: CompletionTerminalProps) {
  const router = useRouter();
  const [checks, setChecks] = useState({
    norminette: false,
    compiles: false,
    pushed: false,
  });

  const allChecked = checks.norminette && checks.compiles && checks.pushed;

  const handleSubmit = () => {
    if (!allChecked) return;
    
    try {
      const stored = localStorage.getItem("42_tracker_progress");
      const progress = stored ? JSON.parse(stored) : {};
      progress[exerciseId] = true;
      localStorage.setItem("42_tracker_progress", JSON.stringify(progress));
      
      alert(`[SUCCESS] Module ${exerciseId} validated. Syncing to intra...`);
      router.push('/');
    } catch (e) {
      console.error("Local storage error:", e);
      alert("[FATAL] Could not write to local storage.");
    }
  };

  return (
    <div className="max-w-4xl mx-auto mt-12 bg-[#050505] border-2 border-[#1A1A1A]">
      <div className="bg-[#111] border-b-2 border-[#1A1A1A] p-4 flex items-center gap-3">
        <Terminal size={20} className="text-[#00FF41]" />
        <h2 className="text-[#E0E0E0] font-mono text-sm uppercase tracking-widest font-bold">Moulinette Pre-Flight Checklist</h2>
      </div>
      
      <div className="p-6 md:p-8 space-y-6">
        <div className="space-y-4 font-mono text-sm">
          <label className="flex items-center gap-4 cursor-pointer group">
            <div className={`relative flex items-center justify-center w-6 h-6 border-2 transition-colors bg-[#0A0A0A] ${checks.norminette ? 'border-[#00FF41]' : 'border-[#333] group-hover:border-[#00FF41]'}`}>
              <input 
                type="checkbox" 
                className="opacity-0 absolute inset-0 cursor-pointer"
                checked={checks.norminette}
                onChange={(e) => setChecks(prev => ({ ...prev, norminette: e.target.checked }))}
              />
              {checks.norminette && <span className="text-[#00FF41] select-none text-lg leading-none">✔</span>}
            </div>
            <span className={`uppercase tracking-wider transition-colors ${checks.norminette ? 'text-white' : 'text-[#888]'}`}>Norminette returned OK.</span>
          </label>

          <label className="flex items-center gap-4 cursor-pointer group">
            <div className={`relative flex items-center justify-center w-6 h-6 border-2 transition-colors bg-[#0A0A0A] ${checks.compiles ? 'border-[#00FF41]' : 'border-[#333] group-hover:border-[#00FF41]'}`}>
              <input 
                type="checkbox" 
                className="opacity-0 absolute inset-0 cursor-pointer"
                checked={checks.compiles}
                onChange={(e) => setChecks(prev => ({ ...prev, compiles: e.target.checked }))}
              />
              {checks.compiles && <span className="text-[#00FF41] select-none text-lg leading-none">✔</span>}
            </div>
            <span className={`uppercase tracking-wider transition-colors ${checks.compiles ? 'text-white' : 'text-[#888]'}`}>Code compiles strictly (-Wall -Wextra -Werror).</span>
          </label>

          <label className="flex items-center gap-4 cursor-pointer group">
            <div className={`relative flex items-center justify-center w-6 h-6 border-2 transition-colors bg-[#0A0A0A] ${checks.pushed ? 'border-[#00FF41]' : 'border-[#333] group-hover:border-[#00FF41]'}`}>
              <input 
                type="checkbox" 
                className="opacity-0 absolute inset-0 cursor-pointer"
                checked={checks.pushed}
                onChange={(e) => setChecks(prev => ({ ...prev, pushed: e.target.checked }))}
              />
              {checks.pushed && <span className="text-[#00FF41] select-none text-lg leading-none">✔</span>}
            </div>
            <span className={`uppercase tracking-wider transition-colors ${checks.pushed ? 'text-white' : 'text-[#888]'}`}>Files pushed to Git.</span>
          </label>
        </div>

        <button
          onClick={handleSubmit}
          disabled={!allChecked}
          className={`w-full py-4 px-6 font-black uppercase tracking-[0.2em] transition-all duration-300 font-mono text-sm md:text-base border-2
            ${allChecked 
              ? 'bg-[#00FF41] text-black border-[#00FF41] hover:bg-white hover:border-white shadow-[0_0_15px_rgba(0,255,65,0.4)] cursor-pointer' 
              : 'bg-[#111] text-[#444] border-[#222] cursor-not-allowed opacity-50'}`}
        >
          {allChecked ? 'Push to Moulinette' : 'Awaiting Clearances'}
        </button>
      </div>
    </div>
  );
}
