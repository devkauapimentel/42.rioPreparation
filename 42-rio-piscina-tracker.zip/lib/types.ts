export interface Exercise {
  id: string;
  title: string;
  description: string;
  isExam?: boolean;
}

export interface Phase {
  id: string;
  title: string;
  days: string;
  description: string;
  xpRequirement: string;
  gatekeeperExamId?: string;
  exercises: Exercise[];
}

export interface Rules {
  title: string;
  items: string[];
}
