import { Phase, Rules } from './types';

export const roadmap: Phase[] = [
  {
    id: "phase-1",
    title: "Shell Mastery",
    days: "Days 00-02",
    description: "Focus on find, grep, chmod, and env. Survive the bash environment.",
    xpRequirement: "Must complete 80% of exercises",
    gatekeeperExamId: "exam00",
    exercises: [
      { id: "day00", title: "ex00", description: "Z: Create a file named Z that returns 'Z' when you run cat Z." },
      { id: "day01", title: "ex01", description: "test: Create a file that shows your environment variables." },
      { id: "exam00", title: "Gatekeeper Exam 01", description: "4-hour exam. Script a recursive search and permission modifier.", isExam: true }
    ]
  },
  {
    id: "phase-2",
    title: "C Foundations",
    days: "Days 03-07",
    description: "Focus on write, while loops, and ASCII math.",
    xpRequirement: "Must complete 100% of Phase 2 core exercises",
    gatekeeperExamId: "e2-exam",
    exercises: [
      { id: "e2-0", title: "ex00", description: "ft_putchar: Write a function that displays the character passed as a parameter." },
      { id: "e2-1", title: "ex01", description: "ft_print_alphabet: Write a function that displays the alphabet in lowercase, on a single line, by ascending order." },
      { id: "e2-2", title: "ex02", description: "ft_print_reverse_alphabet: Write a function that displays the alphabet in lowercase, on a single line, by descending order." },
      { id: "e2-exam", title: "Gatekeeper Exam 02", description: "4-hour exam. Write a function that prints a reverse alphabet grid with specific constraints.", isExam: true }
    ]
  },
  {
    id: "phase-3",
    title: "The Pointer Gate",
    days: "Days 08-14",
    description: "Focus on memory addresses, & and * operators, and passing by reference. The part where most break.",
    xpRequirement: "Must complete 100% of Phase 3 core exercises",
    gatekeeperExamId: "e3-exam",
    exercises: [
      { id: "e3-0", title: "ex00", description: "ft_ft: Create a function that takes a pointer to int as a parameter, and sets the value \"42\" to that int." },
      { id: "e3-1", title: "ex01", description: "ft_swap: Create a function that swaps the value of two integers whose addresses are entered as parameters." },
      { id: "e3-exam", title: "Gatekeeper Exam 03", description: "4-hour exam. Re-implement string manipulation using only pointers.", isExam: true }
    ]
  },
  {
    id: "phase-4",
    title: "Strings and Arrays",
    days: "Days 15-21",
    description: "Rebuild the standard C library. Character by character.",
    xpRequirement: "Must complete 100% of Phase 4 core exercises",
    gatekeeperExamId: "e4-exam",
    exercises: [
      { id: "e4-0", title: "ex00", description: "ft_strlen: Reproduce the behavior of the function strlen." },
      { id: "e4-1", title: "ex01", description: "ft_putstr: Create a function that displays a string of characters on the standard output." },
      { id: "e4-exam", title: "Gatekeeper Exam 04", description: "4-hour exam. Create a custom split function.", isExam: true }
    ]
  },
  {
    id: "phase-5",
    title: "Memory Allocation",
    days: "Days 22-26",
    description: "Dynamic sizing. Data structures.",
    xpRequirement: "Must complete 100% of Phase 5 core exercises",
    gatekeeperExamId: "e5-exam",
    exercises: [
      { id: "e5-0", title: "ex00", description: "ft_strdup: Reproduce the behavior of the function strdup (man strdup)." },
      { id: "e5-exam", title: "Gatekeeper Exam 05", description: "8-hour exam. Final Piscina Test Project.", isExam: true }
    ]
  }
];

export const gameRules: Rules = {
  title: "The Norm",
  items: [
    "Max 25 lines/function",
    "Max 5 vars/function",
    "NO for/switch loops",
    "Indent with 4 spaces",
    "NO AI GENERATION"
  ]
};
